## Stater Code for React Login App

1. At the root of the project run `$ npm install`
1. `$ npm start` or `$ yarn start`
1. Your front-end server is up and running.